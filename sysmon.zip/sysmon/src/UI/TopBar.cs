using System.Drawing.Drawing2D;
using SysMon.Data;

namespace SysMon.UI;

/// <summary>アプリ名・概要と設定のチップ。狭いウィンドウでは操作を折り返す。</summary>
internal sealed class TopBar : Tile
{
    private readonly ContextMenuStrip _zoomMenu = new();

    public TopBar(Model m, AppState app) : base(m, app)
    {
        foreach (int zoom in Settings.ZoomLevels)
        {
            var item = new ToolStripMenuItem($"{zoom}%") { Tag = zoom };
            item.Click += (_, _) =>
            {
                App.Settings.ZoomPercent = zoom;
                App.ApplySettings();
            };
            _zoomMenu.Items.Add(item);
        }
    }

    public int BarHeight
    {
        get
        {
            var t = T;
            int pad = (int)MathF.Round(12 * t.S);
            var c = new Canvas(null, this, t, pad, Width - pad, 0);
            return LayoutChips(c).height;
        }
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        var g = e.Graphics;
        var t = T;
        g.Clear(Theme.Page);
        g.SmoothingMode = SmoothingMode.AntiAlias;
        ResetFrame();
        int pad = (int)MathF.Round(12 * t.S);
        Ui.BeginBatch();
        Build(new Canvas(g, this, t, pad, Width - pad, 0));
        Ui.FlushBatch(g);
    }

    protected override void Build(Canvas c)
    {
        var t = c.T;
        var layout = LayoutChips(c);
        int rowH = c.Px(34);
        Ui.Text(c.G, "SysMon", t.Title, Theme.Ink, c.L, (rowH - t.Title.H()) / 2);
        int lx = c.L + Ui.TextW("SysMon", t.Title) + c.Px(10);
        var s = M.Last;
        var hw = App.Sampler?.Hw;
        if (s != null)
        {
            string summary = $"{Environment.MachineName} · 稼働 {Fmt.Uptime(s.Uptime)} · プロセス {s.Processes:N0}";
            if (hw != null && hw.IsAdmin) summary += hw.PawnIoInstalled ? " · 管理者" : " · 管理者 (PawnIO なし)";
            Ui.Text(c.G, summary, t.Small, Theme.Muted, lx, (rowH - t.Small.H()) / 2, layout.firstLeft - lx - c.Px(8));
        }
    }

    private (int height, int firstLeft) LayoutChips(Canvas c)
    {
        var t = c.T;
        var set = App.Settings;
        int chipH = t.Small.H() + c.Px(6);
        int rowH = Math.Max(c.Px(34), chipH + c.Px(8));
        var chips = new List<(string text, bool on, Action click)>
        {
            ($"表示 {set.ZoomPercent}%", set.ZoomPercent != 100, null),
            ($"更新 {set.IntervalMs / 1000.0:0.#} 秒", false, () =>
            {
                set.IntervalMs = Next(Settings.Intervals, set.IntervalMs);
                App.ApplySettings();
            }),
            ($"履歴 {set.HistorySec} 秒", false, () =>
            {
                set.HistorySec = Next(Settings.Histories, set.HistorySec);
                App.ApplySettings();
            }),
            ("最前面", set.TopMost, () =>
            {
                set.TopMost = !set.TopMost;
                App.ApplySettings();
            }),
        };
        var hw = App.Sampler?.Hw;
        if (hw != null && !hw.IsAdmin)
        {
            string adminText = "管理者で再起動（温度を表示）";
            if (Ui.TextW(adminText, t.Small) + c.Px(14) > c.W) adminText = "管理者で再起動";
            chips.Add((adminText, false, App.RestartElevated));
        }

        int x = c.R, row = 0, firstLeft = c.R;
        int left = c.L + Ui.TextW("SysMon", t.Title) + c.Px(16);
        foreach (var chip in chips)
        {
            int w = Ui.TextW(chip.text, t.Small) + c.Px(14);
            if (x - w < left)
            {
                row++;
                x = c.R;
                left = c.L;
            }
            int y = row * rowH + (rowH - chipH) / 2;
            var anchor = new Point(Math.Max(c.L, x - w), y + chipH);
            Action click = chip.click ?? (() => ShowZoomMenu(anchor));
            x = Ui.Chip(c, x, y, chip.text, chip.on, click) - c.Px(4);
            if (row == 0) firstLeft = x;
        }
        return ((row + 1) * rowH, firstLeft);
    }

    private void ShowZoomMenu(Point location)
    {
        foreach (ToolStripMenuItem item in _zoomMenu.Items)
            item.Checked = App.Settings.ZoomPercent == (int)item.Tag;
        _zoomMenu.Show(this, location);
    }

    protected override void Dispose(bool disposing)
    {
        // Closed は WinForms のメニュー終了処理の途中で発火する。
        // メニューはバーが所有し、バーと一緒に破棄する。
        if (disposing) _zoomMenu.Dispose();
        base.Dispose(disposing);
    }

    private static int Next(int[] options, int current)
    {
        int i = Array.IndexOf(options, current);
        return options[(i + 1) % options.Length];
    }
}
